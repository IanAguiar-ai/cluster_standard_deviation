# cluster_standard_deviation
Proprietary technique designed for simple n-dimensional clustering
